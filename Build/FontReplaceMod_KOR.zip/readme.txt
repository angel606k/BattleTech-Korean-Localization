FontReplaceMod 제작사님(qwe님)께 진심으로 감사의 말씀 드립니다.

한글폰트는 나눔바른고딕을 사용하였습니다.

C:\Users\(계정명)\Documents\My Games\BattleTech\mods 에 압축해제를 하시면 됩니다.

관련 문의 : angel606k@naver.com